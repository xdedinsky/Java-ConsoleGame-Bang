package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.Outputs;
import sk.stuba.fei.uim.oop.game.TextColours;

import java.util.ArrayList;

public class Dynamite extends Card{
    public Dynamite(){
        super("Dynamite");
    }
    Outputs outputs = new Outputs();
    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        player.hand.removeCardFromHand(this);
        player.desk.setOnDesk(this);
    }

    @Override
    public boolean check(Player player,CardsPack cardsPack){
        outputs.boxDynamite();
        if (player.desk.isOnDeskDynamite()){
            if (Card.random.nextInt(8) == 1) {
                System.out.println(TextColours.ANSI_PURPLE  + "Dynamite exploded at "+ player.getName() + "!"+ TextColours.ANSI_RESET);
                player.setNumberOfLives(player.getNumberOfLives() - 3);
                if (player.getNumberOfLives() <= 0) {player.setNumberOfLives(0);}
                cardsPack.addCardSecondary(new Dynamite());
                player.desk.removeCardFromDesk(player.desk.getDynamiteIndex());
                return true;
            }
        }
        player.desk.removeCardFromDesk(player.desk.getDynamiteIndex());
        System.out.println(TextColours.ANSI_PURPLE + "Dynamite didn't explode at "+ player.getName() + "!"+ TextColours.ANSI_RESET);
        return false;
    }
}

