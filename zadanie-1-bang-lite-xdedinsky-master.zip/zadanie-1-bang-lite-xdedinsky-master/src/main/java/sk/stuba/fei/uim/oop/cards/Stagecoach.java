package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;

import java.util.ArrayList;

public class Stagecoach extends Card{
    public Stagecoach(){
        super("Stagecoach");
    }

    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        if (cardsPack.getSizePrimary() < 2) {
            System.out.println("Not enough cards in pack!");
            return;
        }
        player.hand.removeCardFromHand(this);
        cardsPack.addCardSecondary(this);
        for (int i = 0; i < 2; i++) {
            player.hand.addCard(cardsPack.getCard(0));
            cardsPack.removeCardPrimary(cardsPack.getCard(0));
        }
    }
}
