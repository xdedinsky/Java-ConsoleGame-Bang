package sk.stuba.fei.uim.oop.player;

import sk.stuba.fei.uim.oop.cards.Card;
import sk.stuba.fei.uim.oop.cards.Bang;
import sk.stuba.fei.uim.oop.cards.Missed;

import java.util.ArrayList;

public class Hand {
    public ArrayList<Card> hand;
    public Hand() {
        hand = new ArrayList<>();
    }

    public int getHandSize(){return hand.size();}

    public Card getCard(int index) {
        return hand.get(index);
    }

    public int getMissedIndexHand(){
        for (Card temp : hand) {
            if (temp instanceof Missed){
                return hand.indexOf(temp);
            }
        }
        return 0;
    }
    public int getBangIndexHand(){
        for (Card temp : hand) {
            if (temp instanceof Bang){
                return hand.indexOf(temp);
            }
        }
        return 0;
    }

    public void addCard(Card card){
        hand.add(card);
    }

    public void removeCardFromHand(Card card){
        hand.remove(card);
    }

    public void removeCardFromHand(int index){
        hand.remove(index);
    }

    public void printHand(){
        for (int i = 0; i < hand.size(); i++) {

            System.out.println(i + 1 + ". " + hand.get(i).getCardName());


        }
    }

    public void addTwoCardsToHand(ArrayList<Card> cardPack){
        for (int i = 0; i < 2; i++) {
            hand.add(cardPack.get(0));
            cardPack.remove(0);
        }
    }

    public boolean isInHandBang() {
        if (hand.size() == 0){
            return false;
        }
        for (Card temp : hand) {
            if (temp instanceof Bang){
                return true;
            }
        }
        return false;
    }
    public boolean isInHandMissed(){
        if (hand.size() == 0){
            return false;
        }
        for (Card temp : hand) {
            if (temp instanceof Missed){
                return true;
            }
        }
        return false;
    }

}
