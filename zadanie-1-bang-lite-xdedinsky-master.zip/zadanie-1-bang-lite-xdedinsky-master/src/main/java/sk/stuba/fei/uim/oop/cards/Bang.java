package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;
import sk.stuba.fei.uim.oop.game.CardsPack;
import java.util.ArrayList;

public class Bang extends Card{

    public Bang(){
        super("Bang");
    }

    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){

        int count = 0;
        for (Player player1 : players) {
            if (player1.getNumberOfLives() > 0 && player1 != player) {
                count++;
            }
        }

        if (count == 0){
            System.out.println(TextColours.ANSI_PURPLE + "There is no one to shoot at!" + TextColours.ANSI_RESET);
            return;
        }

        player.hand.removeCardFromHand(this);
        cardsPack.addCardSecondary(this);
        Player player2 = printActivePlayersAndChooseOpponent(player, players);
        Card barrel = new Barrel();

        if (player2.desk.isOnDeskBarrel()) {
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has Barrel, his chance to hide behind the Barrel is 25%" + TextColours.ANSI_RESET);
            if (barrel.check(player2, cardsPack)) {
                return;
            }
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has not dodged the shot!" + TextColours.ANSI_RESET);
        }

        Card missed = new Missed();
        if (missed.check(player2, cardsPack)){
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has missed the shot, by card Missed" + TextColours.ANSI_RESET);
            player2.hand.removeCardFromHand(missed);
            return;
        }

        System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has been shot! By card Bang" + TextColours.ANSI_RESET);
        player2.setNumberOfLives(player2.getNumberOfLives() - 1);
    }
    @Override
    public boolean check(Player player, CardsPack cardsPack){
        return player.hand.isInHandBang();
    }
}

