package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.utility.ZKlavesnice;
import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;

import java.util.ArrayList;

public class CatBalou extends Card{
    public CatBalou(){
        super("CatBalou");
    }

    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        int choice;

        Player player2 = printActivePlayersAndChooseOpponent(player, players);
        if (player2.hand.getHandSize() == 0 && player2.desk.getDeskSize() == 0){
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has no cards to discard" + TextColours.ANSI_RESET);
            return;
        }

        player.hand.removeCardFromHand(this);
        cardsPack.addCardSecondary(this);

        if (player2.hand.getHandSize() == 0){
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has no cards to discard in hand" + TextColours.ANSI_RESET);
            int random = Card.random.nextInt(player2.desk.getDeskSize());
            cardsPack.addCardSecondary(player2.desk.getCardFromDesk(random));
            System.out.println(TextColours.ANSI_PURPLE + player2.desk.getCardFromDesk(random).getCardName() +" is discarded from deck" + TextColours.ANSI_RESET);
            player2.desk.removeCardFromDesk(random);
            return;
        }
        if (player2.desk.getDeskSize() == 0){
            System.out.println(TextColours.ANSI_PURPLE + "Player " + player2.getName() + " has no cards to discard on desk" + TextColours.ANSI_RESET);
            int random = Card.random.nextInt(player2.hand.getHandSize());
            cardsPack.addCardSecondary(player2.hand.getCard(random));
            System.out.println(TextColours.ANSI_PURPLE + player2.hand.getCard(random).getCardName() +" is discarded from hand" + TextColours.ANSI_RESET);
            player2.hand.removeCardFromHand(random);
            return;
        }

        do{
            choice = ZKlavesnice.readInt(TextColours.ANSI_BLUE + "Where do you want discard card? 1 - Hand, 2 - Desk" + TextColours.ANSI_RESET);
        }while(choice != 1 && choice != 2);

        int random;
        if (choice == 1){
            random = Card.random.nextInt(player2.hand.getHandSize());
            cardsPack.addCardSecondary(player2.hand.getCard(random));
            System.out.println(TextColours.ANSI_PURPLE + player2.hand.getCard(random).getCardName() +" is discarded from hand" + TextColours.ANSI_RESET);
            player2.hand.removeCardFromHand(random);

        }else{
            random = Card.random.nextInt(player2.desk.getDeskSize());
            cardsPack.addCardSecondary(player2.desk.getCardFromDesk(random));
            System.out.println(TextColours.ANSI_PURPLE + player2.desk.getCardFromDesk(random).getCardName() +" is discarded from desk" + TextColours.ANSI_RESET);
            player2.desk.removeCardFromDesk(random);
        }
    }
}
