package sk.stuba.fei.uim.oop.game;

public class Outputs {
    public void boxLives(){
        System.out.println(TextColours.ANSI_YELLOW + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       │    Lives   │"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
    public void boxBang(){
        System.out.println(TextColours.ANSI_YELLOW + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "───────┤/̵͇̿̿/'̿'̿ ̿ BANG  ├───────"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
    public void boxRound(){
        System.out.println(TextColours.ANSI_RED + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_RED + "───────┤ New  Round ├───────"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_RED + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
    public void boxDesk(){
        System.out.println(TextColours.ANSI_YELLOW + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       │    Desk    │"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
    public void boxDynamite(){
        System.out.println(TextColours.ANSI_YELLOW + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       │  Dynamite  │"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
    public void boxCards(){
        System.out.println(TextColours.ANSI_YELLOW + "       ┌────────────┐"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       │    CARDS   │"+ TextColours.ANSI_RESET);
        System.out.println(TextColours.ANSI_YELLOW + "       └────────────┘"+ TextColours.ANSI_RESET);
    }
}
