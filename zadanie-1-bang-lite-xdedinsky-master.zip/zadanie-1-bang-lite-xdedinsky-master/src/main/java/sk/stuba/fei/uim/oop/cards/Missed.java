package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;

import java.util.ArrayList;

public class Missed extends Card{
    public Missed(){
        super("Missed");
    }
    @Override
    public void play(Player player, ArrayList<Player> players, CardsPack cardsPack){
        System.out.println(TextColours.ANSI_RED + "You can't play this card!" + TextColours.ANSI_RESET);
    }

    @Override
    public boolean check(Player player, CardsPack cardsPack){
        if (player.hand.isInHandMissed()){
            cardsPack.addCardSecondary(new Missed());
            player.hand.removeCardFromHand(player.hand.getMissedIndexHand());
            return true;
        }
        return false;
    }
}
