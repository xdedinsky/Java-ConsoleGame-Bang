package sk.stuba.fei.uim.oop.game;

import sk.stuba.fei.uim.oop.cards.*;

import java.util.ArrayList;


public class CardsPack {
    private final ArrayList<Card> primaryPack;
    private final ArrayList<Card> secondaryPack;

    public CardsPack() {
        this.secondaryPack = new ArrayList<>();
        this.primaryPack = new ArrayList<>();

    }

    public int getSizePrimary() {
        return primaryPack.size();
    }
    public int getSizeSecondary(){return secondaryPack.size();}

    public Card getCard(int index) {
        return primaryPack.get(index);
    }

    public ArrayList<Card> getPrimaryPack() {
        return primaryPack;
    }

    public ArrayList<Card> getSecondaryPack(){return secondaryPack;}

    public void addCardSecondary(Card card){
        secondaryPack.add(card);
    }

    public void addCardPrimary(Card card) {
        primaryPack.add(card);
    }

    public void removeCardPrimary(Card card) {
        primaryPack.remove(card);
    }

    public void shuffle() {
        Card temp;
        for (int i = 0; i < primaryPack.size(); i++) {
            int random = Card.random.nextInt(primaryPack.size());
            temp = primaryPack.get(i);
            primaryPack.set(i, primaryPack.get(random));
            primaryPack.set(random, temp);
        }
    }
}