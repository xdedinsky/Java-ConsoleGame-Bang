package sk.stuba.fei.uim.oop.game;

import sk.stuba.fei.uim.oop.cards.*;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.utility.ZKlavesnice;
import java.util.ArrayList;

public class Game {
    private int numberOfPlayers;
    CardsPack cardsPack = new CardsPack();
    private final Outputs outputs = new Outputs();
    private final ArrayList<Player> players;
    public Game() {

        outputs.boxBang();
        do {
            numberOfPlayers = ZKlavesnice.readInt(TextColours.ANSI_CYAN + "Enter number of players <2,4>"+ TextColours.ANSI_RESET);
        } while (checkInputRange(2, 4, numberOfPlayers));

        players = new ArrayList<>(numberOfPlayers);
        for (int i = 0; i < numberOfPlayers; i++) {
            players.add(new Player(ZKlavesnice.readString(TextColours.ANSI_CYAN + "Enter name of player " + (i + 1) + ":" + TextColours.ANSI_RESET)));
        }

        setCardsPack();
        cardsPack.shuffle();
        startGame();
    }

    private void startGame(){

        for (int i = 0; i < numberOfPlayers; i++) {
            for (int j = 0; j < 4; j++) {
                players.get(i).hand.addCard(cardsPack.getCard(0));
                cardsPack.removeCardPrimary(cardsPack.getCard(0));
            }
        }


        int choice;
        int previousPlayer;

        for (int activePlayer = 0; activePlayer  < numberOfPlayers; activePlayer++) {
            if (players.get(activePlayer).getNumberOfLives() == 0) {
                if (activePlayer == numberOfPlayers - 1) {
                    activePlayer = -1;
                }
                continue;
            }

            outputs.boxRound();
            System.out.println(TextColours.ANSI_RED + "It is " + players.get(activePlayer).getName() + "'s turn" + TextColours.ANSI_RESET);

            if (players.get(activePlayer).desk.isOnDeskDynamite()) {
                if(new Dynamite().check(players.get(activePlayer), cardsPack)){
                    if (players.get(activePlayer).getNumberOfLives() <= 0) {
                        if (activePlayer == numberOfPlayers - 1) {
                            activePlayer = -1;
                        }
                        checkWinner(players);
                        continue;
                    }
                }
                else{
                    previousPlayer = activePlayer - 1;
                    if (previousPlayer < 0) {
                        previousPlayer = numberOfPlayers - 1;
                    }
                    while (players.get(previousPlayer).getNumberOfLives() <= 0) {
                        previousPlayer--;
                        if (previousPlayer < 0) {
                            previousPlayer = numberOfPlayers - 1;
                        }
                    }
                    players.get(previousPlayer).desk.addCardToDesk(new Dynamite());
                }

            }

            if (players.get(activePlayer).desk.isOnDeskPrison()) {
                if(new Prison().check(players.get(activePlayer), cardsPack)){
                    if (activePlayer == numberOfPlayers - 1) {
                        activePlayer = -1;
                    }
                    continue;
                }
            }

            if (cardsPack.getPrimaryPack().size() < 10) {
                moveCardsFromSecPackToPrimPack();
            }

            if (cardsPack.getPrimaryPack().size() < 2) {
                System.out.println(TextColours.ANSI_RED + "Not enough cards in pack to draw cards!" + TextColours.ANSI_RESET);
            }
            else{
                players.get(activePlayer).hand.addTwoCardsToHand(cardsPack.getPrimaryPack());
            }

            boolean b;

            do{
                outputs.boxLives();
                printLives();
                outputs.boxDesk();
                printDesk(players);

                outputs.boxCards();
                System.out.println(TextColours.ANSI_YELLOW + "It is " + players.get(activePlayer).getName() + "'s turn" + TextColours.ANSI_RESET);
                players.get(activePlayer).hand.printHand();

                do {
                    checkWinner(players);
                    if (players.get(activePlayer).hand.getHandSize() == 0) {
                        System.out.println(TextColours.ANSI_RED + "You do not have cards in your hand your turn ended!" + TextColours.ANSI_RESET);
                        choice = -1;
                        break;
                    }
                    choice = ZKlavesnice.readInt(TextColours.ANSI_CYAN + "Enter number of card you want to play (0 for end turn):" + TextColours.ANSI_RESET) - 1;
                    b = checkInputRange(-1, players.get(activePlayer).hand.getHandSize() - 1, choice);
                } while (b);


                if (choice >= 0) {
                    players.get(activePlayer).hand.getCard(choice).play(players.get(activePlayer),players,cardsPack);
                }
                else{break;}

            }while (players.get(activePlayer).getNumberOfLives() > 0);

            while(players.get(activePlayer).hand.getHandSize() > players.get(activePlayer).getNumberOfLives()) {
                do {
                    choice = ZKlavesnice.readInt(TextColours.ANSI_CYAN + "You must discard cards! You have more cards than lives!" + TextColours.ANSI_RESET) - 1;
                    b = checkInputRange(0, players.get(activePlayer).hand.getHandSize(), choice);
                } while (b);
                cardsPack.addCardSecondary(players.get(activePlayer).hand.getCard(choice));
                players.get(activePlayer).hand.removeCardFromHand(players.get(activePlayer).hand.getCard(choice));
            }

            if (activePlayer + 1 == numberOfPlayers) {
                activePlayer = -1;
            }

            discardCardsDeathPlayer(players);
            checkWinner(players);
        }
    }


    private void setCardsPack() {
        for (int i = 0; i < 9 ; i++) {
            if (i == 0){
                for (int j = 0; j < 30; j++) {
                    this.cardsPack.addCardPrimary(new Bang());
                }
                continue;
            }
            if (i == 1){
                for (int j = 0; j < 2; j++) {
                    this.cardsPack.addCardPrimary(new Barrel());
                }
            }
            if (i == 2){
                for (int j = 0; j < 6; j++) {
                    this.cardsPack.addCardPrimary(new CatBalou());
                }
                continue;
            }
            if (i == 3){
                for (int j = 0; j < 4; j++) {
                    this.cardsPack.addCardPrimary(new Stagecoach());
                }
                continue;
            }
            if (i == 4){
                for (int j = 0; j < 1; j++) {
                    this.cardsPack.addCardPrimary(new Dynamite());
                }
                continue;
            }
            if (i == 5){
                for (int j = 0; j < 2; j++) {
                    this.cardsPack.addCardPrimary(new Indians());
                }
                continue;
            }
            if (i == 6){
                for (int j = 0; j < 8; j++) {
                    this.cardsPack.addCardPrimary(new Beer());
                }
                continue;
            }
            if (i == 7){
                for (int j = 0; j < 3; j++) {
                    this.cardsPack.addCardPrimary(new Prison());
                }
                continue;
            }
            if (i == 8){
                for (int j = 0; j < 15; j++) {
                    this.cardsPack.addCardPrimary(new Missed());
                }
            }
        }
    }

    private void printLives(){
        for (int i = 0; i < numberOfPlayers; i++) {
            System.out.println(players.get(i).getName() + ": " + players.get(i).getNumberOfLives());
        }
    }

    private void discardCardsDeathPlayer(ArrayList<Player> players){
        for (int i = 0; i < numberOfPlayers; i++) {

            if (players.get(i).getNumberOfLives() <= 0) {

                if (players.get(i).hand.getHandSize() > 0) {
                    for (int j = 0; j < players.get(i).hand.getHandSize(); j++) {
                        cardsPack.addCardSecondary(players.get(i).hand.getCard(j));
                        players.get(i).hand.removeCardFromHand(players.get(i).hand.getCard(j));
                    }
                }
                if (players.get(i).desk.getDeskSize() > 0) {
                    for (int j = 0; j < players.get(i).desk.getDeskSize(); j++) {
                        cardsPack.addCardSecondary(players.get(i).desk.getCardFromDesk(j));
                        players.get(i).desk.removeCardFromDesk(players.get(i).desk.getCardFromDesk(j));
                    }
                }
            }
        }
    }

    private void checkWinner(ArrayList<Player> players) {
        int numberOfAlivePlayers = 0;
        for (int i = 0; i < numberOfPlayers; i++) {
            if (players.get(i).getNumberOfLives() > 0) {
                numberOfAlivePlayers++;
            }
        }
        if (numberOfAlivePlayers == 1) {
            for (int i = 0; i < numberOfPlayers; i++) {
                if (players.get(i).getNumberOfLives() > 0) {
                    System.out.println(TextColours.ANSI_GREEN + "Player " + players.get(i).getName() + " won!" + TextColours.ANSI_RESET);
                }
            }
            System.exit(0);
        }
    }

    private void printDesk(ArrayList<Player> players) {
        for (Player player : players) {
            System.out.print(player.getName() + ": ");
            int i = 1;
            for (Card card : player.desk.getCardsOnDesk()) {
                System.out.print(i + ". " +card.getCardName() + " ");
                i++;
            }
            System.out.println();
        }
    }

    private boolean checkInputRange(int rangeStart, int rangeEnd, int number) {
        if (number >= rangeStart && number <= rangeEnd) {
            return false;
        }
        System.out.println(TextColours.ANSI_RED + "Wrong input or you cant play this card!" + TextColours.ANSI_RESET);
        return true;
    }

    private void moveCardsFromSecPackToPrimPack(){
        cardsPack.shuffle();
        for (int i = 0; i < cardsPack.getSizeSecondary(); i++) {
            cardsPack.addCardPrimary(cardsPack.getCard(i));
        }
        cardsPack.getSecondaryPack().clear();
    }

}
