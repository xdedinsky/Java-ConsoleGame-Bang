package sk.stuba.fei.uim.oop.player;

import sk.stuba.fei.uim.oop.cards.Barrel;
import sk.stuba.fei.uim.oop.cards.Card;
import sk.stuba.fei.uim.oop.cards.Dynamite;
import sk.stuba.fei.uim.oop.cards.Prison;

import java.util.ArrayList;

public class Desk{
    private final ArrayList<Card> desk;
    public Desk() {
        desk = new ArrayList<>();
    }

    public int getDynamiteIndex(){
        for (Card temp : desk) {
            if (temp instanceof Dynamite){
                return desk.indexOf(temp);
            }
        }
        return 0;
    }

    public int getPrisonIndex(){
        for (Card temp : desk) {
            if (temp instanceof Prison){
                return desk.indexOf(temp);
            }
        }
        return 0;
    }

    public Card getCardFromDesk(int index) {
        return this.desk.get(index);
    }

    public int getDeskSize() {return this.desk.size();}

    public Card[] getCardsOnDesk() {
        Card[] cards = new Card[desk.size()];
        for (int i = 0; i < desk.size(); i++) {
            cards[i] = desk.get(i);
        }
        return cards;
    }

    public void setOnDesk(Card card) {desk.add(card);}

    public void addCardToDesk(Card card) {
        desk.add(card);
    }

    public void removeCardFromDesk(Card card) {desk.remove(card);}

    public void removeCardFromDesk(int index){
        desk.remove(index);
    }

    public boolean isOnDeskDynamite() {
        if (desk.size() == 0){
            return false;
        }
        for (Card temp : desk) {
            if (temp instanceof Dynamite){
                return true;
            }
        }
        return false;
    }

    public boolean isOnDeskBarrel() {
        if (desk.size() == 0){
            return false;
        }
        for (Card temp : desk) {
            if (temp instanceof Barrel){
                return true;
            }
        }
        return false;
    }

    public boolean isOnDeskPrison() {
        if (desk.size() == 0){
            return false;
        }
        for (Card temp : desk) {
            if (temp instanceof Prison){
                return true;
            }
        }
        return false;
    }
}
