package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import java.util.ArrayList;

public class Beer extends Card{
    public Beer(){
        super("Beer");
    }

    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        player.setNumberOfLives(player.getNumberOfLives() + 1);
        player.hand.removeCardFromHand(this);
        cardsPack.addCardSecondary(new Beer());
    }
}

