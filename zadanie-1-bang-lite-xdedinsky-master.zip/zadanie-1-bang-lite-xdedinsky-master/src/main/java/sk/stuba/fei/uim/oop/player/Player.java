package sk.stuba.fei.uim.oop.player;

public class Player{
    private final String name;
    private int NumberOfLives;
    public Desk desk;
    public Hand hand;

    public Player(String name){
        this.name = name;
        this.NumberOfLives = 4;
        this.hand = new Hand();
        this.desk = new Desk();
    }

    public String getName() {return name;}

    public int getNumberOfLives(){return this.NumberOfLives;}

    public void setNumberOfLives(int Number){this.NumberOfLives =  Number;}

}
