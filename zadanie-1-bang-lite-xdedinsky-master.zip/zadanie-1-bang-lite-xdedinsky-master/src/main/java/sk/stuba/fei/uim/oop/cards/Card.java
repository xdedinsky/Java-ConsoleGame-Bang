package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;
import sk.stuba.fei.uim.oop.utility.ZKlavesnice;
import java.util.ArrayList;
import java.util.Random;

public abstract class Card {
    private final String name;
    public static Random random = new Random();

    public Card(String name){
        this.name = name;

    }

    public Card() {this.name = "";}

    public String getCardName(){
        return name;
    }

    public void play(Player player, ArrayList<Player> players, CardsPack cardsPack) {}

    public boolean check(Player player, CardsPack cardsPack){
        return false;
    }

    public Player printActivePlayersAndChooseOpponent(Player player, ArrayList<Player> players) {
        int i = 1;
        System.out.println(TextColours.ANSI_BLACK + "------OPPONENTS------" + TextColours.ANSI_RESET);
        for (Player p : players) {
            if (p != player && p.getNumberOfLives() > 0) {
                System.out.println(i + ". "+ p.getName());
            }
            i++;
        }
        int choice;
        do {
            choice = ZKlavesnice.readInt(TextColours.ANSI_CYAN + "Enter number of player you want to play against:" + TextColours.ANSI_RESET);
        } while (checkInputRange(1, players.size(), choice) || players.get(choice - 1) == player || players.get(choice - 1).getNumberOfLives() == 0);
        return players.get(choice - 1);
    }

    public boolean checkInputRange(int rangeStart, int rangeEnd, int number) {
        if (number >= rangeStart && number <= rangeEnd) {
            return false;
        }
        System.out.println(TextColours.ANSI_RED + "Wrong input or you cant play this card!" + TextColours.ANSI_RESET);
        return true;
    }

}
