package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;

import java.util.ArrayList;

public class Barrel extends Card{
    public Barrel(){
        super("Barrel");
    }

    @Override
    public void play(Player player, ArrayList<Player> players, CardsPack cardsPack) {
        for (Card card : player.desk.getCardsOnDesk()) {
            if (card instanceof Barrel) {
                System.out.println(TextColours.ANSI_PURPLE + "Player " + player.getName() + " has already Barrel on desk!" + TextColours.ANSI_RESET);
                return;
            }
        }
        player.desk.setOnDesk(this);
        player.hand.removeCardFromHand(this);
    }

    @Override
    public boolean check(Player player, CardsPack cardsPack){
        if (player.desk.isOnDeskBarrel()){
            if (Card.random.nextInt(4) == 1) {
                System.out.println(TextColours.ANSI_PURPLE + player.getName() + " have dodged the shot!" + TextColours.ANSI_RESET);
                return true;
            }
        }
        return false;
    }
}
