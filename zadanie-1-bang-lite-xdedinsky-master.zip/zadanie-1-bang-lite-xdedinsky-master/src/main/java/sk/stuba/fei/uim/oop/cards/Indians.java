package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;
import java.util.ArrayList;

public class Indians extends Card{
    public Indians(){
        super("Indians");
    }
    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        player.hand.removeCardFromHand(this);
        cardsPack.addCardSecondary(this);

        for (Player value : players) {
            if (value == player || value.getNumberOfLives() == 0) {
                continue;
            }
            if (value.hand.isInHandBang()) {
                cardsPack.addCardSecondary(new Bang());
                value.hand.removeCardFromHand(value.hand.getBangIndexHand());
                System.out.println(TextColours.ANSI_PURPLE + "Player " + value.getName() + " has missed shot by card Bang!" + TextColours.ANSI_RESET);
                continue;
            }
            value.setNumberOfLives(value.getNumberOfLives() - 1);
            System.out.println(TextColours.ANSI_PURPLE + "Player " + value.getName() + " has been shot! By card Indians" + TextColours.ANSI_RESET);
        }
    }
}