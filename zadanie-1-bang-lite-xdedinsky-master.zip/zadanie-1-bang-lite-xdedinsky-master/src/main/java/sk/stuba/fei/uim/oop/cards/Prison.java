package sk.stuba.fei.uim.oop.cards;

import sk.stuba.fei.uim.oop.game.CardsPack;
import sk.stuba.fei.uim.oop.player.Player;
import sk.stuba.fei.uim.oop.game.TextColours;

import java.util.ArrayList;

public class Prison extends Card{
    public Prison(){super("Prison");}
    @Override
    public void play(Player player , ArrayList<Player> players, CardsPack cardsPack){
        Player opponent = printActivePlayersAndChooseOpponent(player, players);
        for (Card card : opponent.desk.getCardsOnDesk()) {
            if (card instanceof Prison) {
                System.out.println(TextColours.ANSI_RED + "Player " + opponent.getName() + " has already Prison on desk!" + TextColours.ANSI_RESET);
                return;
            }
        }
        System.out.println(TextColours.ANSI_CYAN + "Player " + opponent.getName() + " is now in Prison!" + TextColours.ANSI_RESET);
        opponent.desk.setOnDesk(this);
        player.hand.removeCardFromHand(this);
    }
    @Override
    public boolean check(Player player, CardsPack cardsPack) {
        player.desk.removeCardFromDesk(player.desk.getPrisonIndex());
        cardsPack.addCardSecondary(this);
        if (Card.random.nextInt(4) == 0) {
            System.out.println(TextColours.ANSI_RED + "Player " + player.getName() + " has escaped from Prison!" + TextColours.ANSI_RESET);
            return false;
        }
        System.out.println(TextColours.ANSI_RED + "Player " + player.getName() + " did not escaped from Prison!" + TextColours.ANSI_RESET);
        return true;
    }
}
